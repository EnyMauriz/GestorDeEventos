package projetodb.main;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Scanner;
import java.sql.*;
import java.time.format.DateTimeFormatter;

public class Eventos {
    private int idTipoEvento;
    private int idIngresso;
    private int idPalestrante;
    private String descricao;
    private LocalDate dataEvento;
    private LocalTime horario;
    private LocalTime duracao;
    private int qtdMax;
    
    public Eventos( int idTipoEvento, int idIngresso, int idPalestrante, String descricao, 
                   LocalDate dataEvento, LocalTime horario, LocalTime duracao, int qtdMax) {
        this.idTipoEvento = idTipoEvento;
        this.idIngresso = idIngresso;
        this.idPalestrante = idPalestrante;
        this.descricao = descricao;
        this.dataEvento = dataEvento;
        this.horario = horario;
        this.duracao = duracao;
        this.qtdMax = qtdMax;
    }

    public static void createEvento() {
    Scanner scanner = new Scanner(System.in);
    DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");

    System.out.println("Insira o ID do tipo de evento: ");
    int idTipoEvento = scanner.nextInt();

    System.out.println("Insira o ID do ingresso: ");
    int idIngresso = scanner.nextInt();

    System.out.println("Insira o ID do palestrante: ");
    int idPalestrante = scanner.nextInt();

    System.out.println("Insira a descrição do evento: ");
    scanner.nextLine(); 
    String descricao = scanner.nextLine();

    System.out.println("Insira a data do evento (dd/MM/yyyy): ");
    String dataEventoStr = scanner.nextLine();
    LocalDate dataEvento = LocalDate.parse(dataEventoStr, dateFormatter);

    System.out.println("Insira o horário do evento (HH:mm): ");
    String horarioStr = scanner.nextLine();
    LocalTime horario = LocalTime.parse(horarioStr, timeFormatter);

    System.out.println("Insira a duração do evento (HH:mm): ");
    String duracaoStr = scanner.nextLine();
    LocalTime duracao = LocalTime.parse(duracaoStr, timeFormatter);

    System.out.println("Insira a quantidade máxima de participantes: ");
    int qtdMax = scanner.nextInt();

    String sql = "INSERT INTO evento (idtipo_evento, idingresso, idpalestrante, descricao, data_evento, horario, duracao, qtd_max) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    try (Connection conexao = ConexaoBanco.obterConexao();
         PreparedStatement stmt = conexao.prepareStatement(sql)) {
        
        stmt.setInt(1, idTipoEvento);
        stmt.setInt(2, idIngresso);
        stmt.setInt(3, idPalestrante);
        stmt.setString(4, descricao);
        stmt.setDate(5, Date.valueOf(dataEvento));
        stmt.setTime(6, Time.valueOf(horario));
        stmt.setTime(7, Time.valueOf(duracao));
        stmt.setInt(8, qtdMax);
        
        stmt.executeUpdate();
        System.out.println("Evento inserido com sucesso.");
        
    } catch (SQLException ex) {
        System.out.println("Erro ao inserir evento: " + ex.getMessage());
    }
}
    
    public static boolean verifyEvento(int idEvento) {
    String sql = "SELECT COUNT(*) FROM evento WHERE idevento = ?";

    try (Connection conexao = ConexaoBanco.obterConexao();
         PreparedStatement stmt = conexao.prepareStatement(sql)) {
    
        stmt.setInt(1, idEvento);
        ResultSet rs = stmt.executeQuery();
    
        if (rs.next()) {
            int count = rs.getInt(1);  
            return count > 0; 
        }
    } catch (SQLException ex) {
        System.out.println("Erro: " + ex.getMessage());
    }

    return false;
}
    
    public static void updateEvento(int idEvento) {
    if (verifyEvento(idEvento)) {
        Scanner scanner = new Scanner(System.in);
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");

        System.out.println("Atualize os dados do evento:");
        System.out.print("Novo ID do tipo de evento: ");
        int idTipoEvento = scanner.nextInt();

        System.out.print("Novo ID do ingresso: ");
        int idIngresso = scanner.nextInt();

        System.out.print("Novo ID do palestrante: ");
        int idPalestrante = scanner.nextInt();

        System.out.print("Nova descrição: ");
        scanner.nextLine();
        String descricao = scanner.nextLine();

        System.out.print("Nova data (dd/MM/yyyy): ");
        String dataEventoStr = scanner.nextLine();
        LocalDate dataEvento = LocalDate.parse(dataEventoStr, dateFormatter);

        System.out.print("Novo horário (HH:mm): ");
        String horarioStr = scanner.nextLine();
        LocalTime horario = LocalTime.parse(horarioStr, timeFormatter);

        System.out.print("Nova duração (HH:mm): ");
        String duracaoStr = scanner.nextLine();
        LocalTime duracao = LocalTime.parse(duracaoStr, timeFormatter);

        System.out.print("Nova quantidade máxima de participantes: ");
        int qtdMax = scanner.nextInt();

        String sql = "UPDATE evento SET idtipo_evento = ?, idingresso = ?, idpalestrante = ?, descricao = ?, data_evento = ?, horario = ?, duracao = ?, qtd_max = ? WHERE idevento = ?";

        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
             
            stmt.setInt(1, idTipoEvento);
            stmt.setInt(2, idIngresso);
            stmt.setInt(3, idPalestrante);
            stmt.setString(4, descricao);
            stmt.setDate(5, Date.valueOf(dataEvento));
            stmt.setTime(6, Time.valueOf(horario));
            stmt.setTime(7, Time.valueOf(duracao));
            stmt.setInt(8, qtdMax);
            stmt.setInt(9, idEvento);
            
            int linhasAfetadas = stmt.executeUpdate();
            
            if (linhasAfetadas > 0) {
                System.out.println(linhasAfetadas + " Evento atualizado com sucesso.");
            } else {
                System.out.println("Nenhum evento foi atualizado.");
            }
            
        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar evento: " + ex.getMessage());
        }
    } else {
        System.out.println("Evento não encontrado. Atualização não realizada.");
    }
}
    
    public static void deleteEvento(int idEvento) {
    if (verifyEvento(idEvento)) {
        String sql = "DELETE FROM evento WHERE idevento = ?";

        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
             
            stmt.setInt(1, idEvento);
            
            int linhasAfetadas = stmt.executeUpdate();
            
            if (linhasAfetadas > 0) {
                System.out.println(linhasAfetadas + " Evento deletado com sucesso.");
            } else {
                System.out.println("Nenhum evento foi deletado.");
            }
            
        } catch (SQLException ex) {
            System.out.println("Erro ao deletar evento: " + ex.getMessage());
        }
    } else {
        System.out.println("Evento não encontrado.");
    }
}
    
    public static void readEventos() {
    String sql = "SELECT * FROM evento";
    
    try (Connection conexao = ConexaoBanco.obterConexao();
         PreparedStatement stmt = conexao.prepareStatement(sql)) {
        
        ResultSet rs = stmt.executeQuery();
        if (!rs.isBeforeFirst()) {
            System.out.println("Nenhum evento encontrado.");
        }
        
        while (rs.next()) {
            int idEvento = rs.getInt("idevento");
            int idTipoEvento = rs.getInt("idtipo_evento");
            int idIngresso = rs.getInt("idingresso");
            int idPalestrante = rs.getInt("idpalestrante");
            String descricao = rs.getString("descricao");
            LocalDate dataEvento = rs.getDate("data_evento").toLocalDate();
            LocalTime horario = rs.getTime("horario").toLocalTime();
            LocalTime duracao = rs.getTime("duracao").toLocalTime();
            int qtdMax = rs.getInt("qtd_max");
            
            System.out.println("");
            System.out.println("Dados do evento: ");
            System.out.println("ID Evento: " + idEvento);
            System.out.println("ID Tipo Evento: " + idTipoEvento);
            System.out.println("ID Ingresso: " + idIngresso);
            System.out.println("ID Palestrante: " + idPalestrante);
            System.out.println("Descrição: " + descricao);
            System.out.println("Data Evento: " + dataEvento);
            System.out.println("Horário: " + horario);
            System.out.println("Duração: " + duracao);
            System.out.println("Quantidade máxima de participantes: " + qtdMax);
        }
        
    } catch (SQLException ex) {
        System.out.println("Erro ao consultar eventos: " + ex.getMessage());
    }
}

    
    public int getIdTipoEvento() {
        return idTipoEvento;
    }

    public void setIdTipoEvento(int idTipoEvento) {
        this.idTipoEvento = idTipoEvento;
    }

    public int getIdIngresso() {
        return idIngresso;
    }

    public void setIdIngresso(int idIngresso) {
        this.idIngresso = idIngresso;
    }

    public int getIdPalestrante() {
        return idPalestrante;
    }

    public void setIdPalestrante(int idPalestrante) {
        this.idPalestrante = idPalestrante;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public LocalDate getDataEvento() {
        return dataEvento;
    }

    public void setDataEvento(LocalDate dataEvento) {
        this.dataEvento = dataEvento;
    }

    public LocalTime getHorario() {
        return horario;
    }

    public void setHorario(LocalTime horario) {
        this.horario = horario;
    }

    public LocalTime getDuracao() {
        return duracao;
    }

    public void setDuracao(LocalTime duracao) {
        this.duracao = duracao;
    }

    public int getQtdMax() {
        return qtdMax;
    }

    public void setQtdMax(int qtdMax) {
        this.qtdMax = qtdMax;
    }
    
    public void exibirInformações(){
        System.out.println("Informações do Evento:");
        System.out.println("ID do Tipo de Evento: " + idTipoEvento);
        System.out.println("ID do Ingresso: " + idIngresso);
        System.out.println("ID do Palestrante: " + idPalestrante);
        System.out.println("Descrição: " + descricao);
        System.out.println("Data do Evento: " + dataEvento);
        System.out.println("Horário: " + horario);
        System.out.println("Duração: " + duracao);
        System.out.println("Quantidade Máxima: " + qtdMax);
    }
}
