package projetodb.main;
import java.sql.*;

public class ConexaoBanco {
    private static final String URL = "jdbc:mysql://localhost/sistema_de_gestao_de_eventos";
    private static final String USUARIO = "root";
    private static final String SENHA = "316497a.i";
    
    public static Connection obterConexao() throws SQLException{
        return DriverManager.getConnection(URL, USUARIO, SENHA);
    }
}
