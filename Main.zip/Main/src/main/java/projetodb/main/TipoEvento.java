package projetodb.main;

import java.sql.*;
import java.util.Scanner;

public class TipoEvento {
    private String tipo;
    
    
    public static void createTipoEvento() {
    Scanner scanner = new Scanner(System.in);
    
    System.out.println("Insira o tipo de evento: ");
    String tipo = scanner.nextLine();
    
    String sql = "INSERT INTO tipo_evento (tipo) VALUES (?)";
    
    try (Connection conexao = ConexaoBanco.obterConexao();
         PreparedStatement stmt = conexao.prepareStatement(sql)) {
        
        stmt.setString(1, tipo);
        
        stmt.executeUpdate();
        System.out.println("Tipo de evento inserido com sucesso.");
        
    } catch (SQLException ex) {
        System.out.println("Erro ao inserir tipo de evento: " + ex.getMessage());
    }
}
    
    public static boolean verifyTipoEvento(int idTipoEvento) {
    String sql = "SELECT COUNT(*) FROM tipo_evento WHERE idtipo_evento = ?";

    try (Connection conexao = ConexaoBanco.obterConexao();
         PreparedStatement stmt = conexao.prepareStatement(sql)) {
    
        stmt.setInt(1, idTipoEvento);
        ResultSet rs = stmt.executeQuery();
    
        if (rs.next()) {
            int count = rs.getInt(1);  
            return count > 0; 
        }
    } catch (SQLException ex) {
        System.out.println("Erro: " + ex.getMessage());
    }

    return false;
}
    
    public static void updateTipoEvento(int idTipoEvento) {
    if (verifyTipoEvento(idTipoEvento)) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Digite a atualização para o tipo de evento: ");
        System.out.print("Insira o novo nome para o tipo de evento: ");
        String novoTipo = scanner.nextLine();
        
        String sql = "UPDATE tipo_evento SET tipo = ? WHERE idtipo_evento = ?";
        
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
             
            stmt.setString(1, novoTipo);
            stmt.setInt(2, idTipoEvento);
            
            int linhasAfetadas = stmt.executeUpdate();
            
            if (linhasAfetadas > 0) {
                System.out.println(linhasAfetadas + " Tipo de evento atualizado com sucesso.");
            } else {
                System.out.println("Nenhum tipo de evento foi atualizado.");
            }
            
        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar tipo de evento: " + ex.getMessage());
        }
    } else {
        System.out.println("Tipo de evento não encontrado. Atualização não realizada.");
    }
}

    public static void deleteTipoEvento(int idTipoEvento) {
    if (verifyTipoEvento(idTipoEvento)) {
        String sql = "DELETE FROM tipo_evento WHERE idtipo_evento = ?;";
        
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
             
            stmt.setInt(1, idTipoEvento);
            
            int linhasAfetadas = stmt.executeUpdate();
            
            if (linhasAfetadas > 0) {
                System.out.println(linhasAfetadas + " Tipo de evento deletado com sucesso.");
            } else {
                System.out.println("Nenhum tipo de evento foi deletado.");
            }
            
        } catch (SQLException ex) {
            System.out.println("Erro na consulta SQL: " + ex.getMessage());
        }
        
    } else {
        System.out.println("Tipo de evento não encontrado.");
    }
}

    public static void readTipo(){
        String sql = "SELECT * FROM tipo_evento;";
        
        try(Connection conexao = ConexaoBanco.obterConexao();
                PreparedStatement stmt = conexao.prepareStatement(sql)){
            
            ResultSet rs = stmt.executeQuery();
            if(!rs.isBeforeFirst()){
                System.out.println("Nenhum tipo de evento encontrado.");
            }
            
            while(rs.next()){
                
                int id = rs.getInt("idtipo_evento");
                String tipo = rs.getString("tipo");
                
                System.out.println("");
                System.out.println("Tipos de evento disponíveis: ");
                System.out.println("Id: " + id);
                System.out.println("Tipo de evento: " + tipo);
            }
            
        } catch (SQLException ex) {
            System.out.println("Erro na consulta SQL: " + ex.getMessage());
        }
        
        
    }
    
    public TipoEvento(String tipo){
        this.tipo = tipo;
    }
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    public void exibirInformacoes(){
        System.out.println("Informações do tipo de evento: ");
        System.out.println("Tipo de evento: " + tipo);
    }
    
}
