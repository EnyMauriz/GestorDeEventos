package projetodb.main;

import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
public class Palestrantes extends Pessoas {
    
    public Palestrantes(String nome, String cpf, LocalDate dataNascimento, String endereco, String email, String celular){
    super (nome, cpf, dataNascimento, endereco, email, celular);
    }

    public void exibirInformacoes(){
        System.out.println("Informações do palestrante: ");
        super.exibirDetalhes();
    }
    
    public static void createPalestrantes(){
        Scanner scanner = new Scanner(System.in);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        
        System.out.println("Insira o nome do palestrantes: ");
        String nome = scanner.nextLine();
        
        System.out.print("Insira o CPF do palestrante: ");
        String cpf = scanner.nextLine();

        System.out.print("Insira a data de nascimento (dd/MM/yyyy): ");
        String dataNascimentoStr = scanner.nextLine();
        LocalDate dataNascimento = LocalDate.parse(dataNascimentoStr, formatter);

        System.out.print("Insira o endereço do palestrante: ");
        String endereco = scanner.nextLine();

        System.out.print("Insira o email do palestrante: ");
        String email = scanner.nextLine();

        System.out.print("Insira o número de celular do palestrante: ");
        String celular = scanner.nextLine();
        
        String sql = "INSERT INTO palestrante (nome,cpf,data_nascimento, endereco, email, celular) VALUES (?,?,?,?,?,?)";
        
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)){
            stmt.setString(1, nome);
            stmt.setString(2, cpf);
            stmt.setDate(3, Date.valueOf(dataNascimento));
            stmt.setString(4, endereco);
            stmt.setString(5, email);
            stmt.setString(6, celular);
            
            stmt.executeUpdate();
            System.out.println("Palestrante inserido com sucesso.");
            
        } catch (SQLException ex) {
            System.out.println("Erro ao inserir palestrante: " + ex.getMessage());
        }
        
    }
        
    public static boolean verifyPalestrante(String cpf) {
    if (cpf == null || cpf.trim().isEmpty()) {
        System.out.println("O CPF deve ser fornecido.");
        return false;
    }

    String sql = "SELECT COUNT(*) FROM palestrante WHERE cpf = ?";

    try (Connection conexao = ConexaoBanco.obterConexao(); 
         PreparedStatement stmt = conexao.prepareStatement(sql)) {
    
        stmt.setString(1, cpf.trim());
        ResultSet rs = stmt.executeQuery();
    
        if (rs.next()) {
            int count = rs.getInt(1);  
            return count > 0; 
        }
    } catch (SQLException ex) {
        System.out.println("Erro: " + ex.getMessage());
    }

    return false; 
}

    public static void updatePalestrante(String cpf) {
    if (verifyPalestrante(cpf)){
        Scanner scanner = new Scanner(System.in);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        
        System.out.println("Digite as atualizações do palestrante: ");
        System.out.print("Insira a nova data de nascimento (dd/MM/yyyy): ");
        String dataNascimentoStr = scanner.nextLine();
        LocalDate dataNascimento1 = LocalDate.parse(dataNascimentoStr, formatter);

        System.out.print("Insira o endereço do palestrante: ");
        String endereco1 = scanner.nextLine();

        System.out.print("Insira o email do palestrante: ");
        String email1 = scanner.nextLine();

        System.out.print("Insira o número de celular do palestrante: ");
        String celular1 = scanner.nextLine();
        
        String sql = "UPDATE palestrante SET data_nascimento = ?, endereco = ?, email = ?, celular = ? WHERE cpf = ?";

        try (Connection conexao = ConexaoBanco.obterConexao(); 
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            
            
            stmt.setDate(1, Date.valueOf(dataNascimento1)); 
            stmt.setString(2, endereco1);
            stmt.setString(3, email1);
            stmt.setString(4, celular1);
            stmt.setString(5, cpf);
            
            int linhasAfetadas = stmt.executeUpdate();
            
            if (linhasAfetadas > 0) {
                System.out.println(linhasAfetadas + " palestrante atualizado com sucesso.");
            } else {
                System.out.println("Nenhum palestrante foi atualizado.");
            }
            
        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar palestrante: " + ex.getMessage());
        }
    } else {
        System.out.println("Palestrante não encontrado. Atualização não realizada.");
    }
}

    public static void deletePalestrante(String cpf) {
    if (verifyPalestrante(cpf)) {
        String sql = "DELETE FROM palestrante WHERE idpalestrante = (SELECT idpalestrante FROM (SELECT idpalestrante FROM palestrante WHERE cpf = ?) AS temp);";
        
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            
            stmt.setString(1, cpf);
            
            int linhasAfetadas = stmt.executeUpdate();
        
            if (linhasAfetadas > 0) {
                System.out.println(linhasAfetadas + " Palestrante deletado com sucesso.");
            } else {
                System.out.println("Nenhum palestrante foi deletado.");
            }
            
        } catch (SQLException ex) {
            System.out.println("Erro na consulta SQL. Erro: " + ex.getMessage());
        }
        
    } else {
        System.out.println("Palestrante não encontrado.");
    }
}

    public static void readPalestrantes() {
    String sql = "SELECT * FROM palestrante;";
    
    try (Connection conexao = ConexaoBanco.obterConexao();
         PreparedStatement stmt = conexao.prepareStatement(sql)) {
        
        ResultSet rs = stmt.executeQuery();
        if (!rs.isBeforeFirst()) {
            System.out.println("Nenhum palestrante encontrado.");
        }
        
        while (rs.next()) {
            int idPalestrante = rs.getInt("idPalestrante");
            String nome = rs.getString("nome");
            String cpf = rs.getString("cpf");
            java.sql.Date dataNascimento = rs.getDate("data_nascimento");
            String endereco = rs.getString("endereco");
            String email = rs.getString("email");
            String celular = rs.getString("celular");
            
            System.out.println("");
            System.out.println("Dados do palestrante " + nome + ":");
            System.out.println("Id: " + idPalestrante);
            System.out.println("CPF: " + cpf);
            System.out.println("Data de nascimento: " + dataNascimento);
            System.out.println("Endereço: " + endereco);
            System.out.println("Email: " + email);
            System.out.println("Celular: " + celular);
        }
        
    } catch (SQLException ex) {
        System.out.println("Erro na consulta SQL. ERRO: " + ex.getMessage());
    }
}

    
}
