package projetodb.main;

import java.time.LocalDate;
import java.sql.*;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Participantes extends Pessoas {
    
    public Participantes(String nome, String cpf, LocalDate dataNascimento, String endereco, String email, String celular){
    super (nome, cpf, dataNascimento, endereco, email, celular);
        
    }
    
    public void exibirInformacoes(){
        System.out.println("Informações do Participante: ");
        super.exibirDetalhes();
    }
    
    public static void createParticipantes(){
        Scanner scanner = new Scanner(System.in);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        
        System.out.println("Insira o nome do participante: ");
        String nome = scanner.nextLine();
        
        System.out.print("Insira o CPF do participante: ");
        String cpf = scanner.nextLine();

        System.out.print("Insira a data de nascimento (dd/MM/yyyy): ");
        String dataNascimentoStr = scanner.nextLine();
        LocalDate dataNascimento = LocalDate.parse(dataNascimentoStr, formatter);

        System.out.print("Insira o endereço do participante: ");
        String endereco = scanner.nextLine();

        System.out.print("Insira o email do participante: ");
        String email = scanner.nextLine();

        System.out.print("Insira o número de celular do participante: ");
        String celular = scanner.nextLine();
        
        String sql = "INSERT INTO participante (nome,cpf,data_nascimento, endereco, email, celular) VALUES (?,?,?,?,?,?)";
        
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)){
            stmt.setString(1, nome);
            stmt.setString(2, cpf);
            stmt.setDate(3, Date.valueOf(dataNascimento));
            stmt.setString(4, endereco);
            stmt.setString(5, email);
            stmt.setString(6, celular);
            
            stmt.executeUpdate();
            System.out.println("Participante inserido com sucesso.");
            
        } catch (SQLException ex) {
            System.out.println("Erro ao inserir participante: " + ex.getMessage());
        }
        
    }
    
    public static boolean verifyParticipante(String cpf) {
        if (cpf == null || cpf.trim().isEmpty()) {
        System.out.println("O CPF deve ser fornecido.");
        return false;
    }

        String sql = "SELECT COUNT(*) FROM participante WHERE cpf = ?";

        try (Connection conexao = ConexaoBanco.obterConexao(); 
            PreparedStatement stmt = conexao.prepareStatement(sql)) {
        
            stmt.setString(1, cpf.trim());
            ResultSet rs = stmt.executeQuery();
        
            if (rs.next()) {
             int count = rs.getInt(1);  
             return count > 0; 
            }} catch (SQLException ex) {
               System.out.println("Erro: " + ex.getMessage());
            }
    
    return false; 
}
    
    public static void updateParticipante(String cpf) {
    if (verifyParticipante(cpf)) {
        Scanner scanner = new Scanner(System.in);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        
        System.out.println("Digite as atualizações do participante: ");
        System.out.print("Insira a nova data de nascimento (dd/MM/yyyy): ");
        String dataNascimentoStr = scanner.nextLine();
        LocalDate dataNascimento1 = LocalDate.parse(dataNascimentoStr, formatter);

        System.out.print("Insira o endereço do participante: ");
        String endereco1 = scanner.nextLine();

        System.out.print("Insira o email do participante: ");
        String email1 = scanner.nextLine();

        System.out.print("Insira o número de celular do participante: ");
        String celular1 = scanner.nextLine();
        
        String sql = "UPDATE participante SET data_nascimento = ?, endereco = ?, email = ?, celular = ? WHERE cpf = ?";

        try (Connection conexao = ConexaoBanco.obterConexao(); 
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            
            
            stmt.setDate(1, Date.valueOf(dataNascimento1)); 
            stmt.setString(2, endereco1);
            stmt.setString(3, email1);
            stmt.setString(4, celular1);
            stmt.setString(5, cpf);
            
            int linhasAfetadas = stmt.executeUpdate();
            
            if (linhasAfetadas > 0) {
                System.out.println(linhasAfetadas + " Participante atualizado com sucesso.");
            } else {
                System.out.println("Nenhum participante foi atualizado.");
            }
            
        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar participante: " + ex.getMessage());
        }
    } else {
        System.out.println("Participante não encontrado. Atualização não realizada.");
    }
}
    
    public static void deleteParticipante(String cpf){
        if(verifyParticipante(cpf)){
            String sql = "DELETE FROM participante WHERE idparticipante = (SELECT idparticipante FROM (SELECT idparticipante FROM participante WHERE cpf = ?) AS temp);";
            
            try(Connection conexao = ConexaoBanco.obterConexao();
                    PreparedStatement stmt = conexao.prepareStatement(sql)){
                
                stmt.setString(1, cpf);
                
                int linhasAfetadas = stmt.executeUpdate();
            
            if (linhasAfetadas > 0) {
                System.out.println(linhasAfetadas + " Participante deletado com sucesso.");
            } else {
                System.out.println("Nenhum participante foi deletado.");
            }
                
            } catch (SQLException ex) {
                System.out.println("Erro na consulta sql. Erro: " + ex.getMessage());
            }
            
            
        } else {
            System.out.println("Participante não encontrado.");
        }
        
    }
    
    public static void readParticipantes(){
        String sql = "SELECT * FROM participante;";
        
        try(Connection conexao = ConexaoBanco.obterConexao();
                PreparedStatement stmt = conexao.prepareStatement(sql)){
            
            ResultSet rs = stmt.executeQuery();
            if(!rs.isBeforeFirst()){
                System.out.println("Nenhum participante encontrado.");
            }
            
            while(rs.next()){
                int idParticipante = rs.getInt("idParticipante");
                String nome = rs.getString("nome");
                String cpf = rs.getString("cpf");
                java.sql.Date dataNascimento = rs.getDate("data_nascimento");
                String endereco = rs.getString("endereco");
                String email = rs.getString("email");
                String celular = rs.getString("celular");
                
                System.out.println("");
                System.out.println("Dados do participante " + nome + ":");
                System.out.println("Id: " + idParticipante);
                System.out.println("CPF: " + cpf);
                System.out.println("Data de nascimento: " + dataNascimento);
                System.out.println("Endereço: " + endereco);
                System.out.println("Email: " + email);
                System.out.println("Celular: " + celular);
                
            }
            
        } catch (SQLException ex) {
            System.out.println("Erro na consulta SQL. ERRO: " + ex.getMessage());
        }
    }


    }

