package projetodb.main;

import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
       
        System.out.println("Bem vindo(a) ao seu gestor de eventos! ");
        System.out.println("");
        System.out.println("Por favor, selecione a tabela que você gostaria de modificar.");
        System.out.println("1. Palestrantes.");
        System.out.println("2. Participantes.");
        System.out.println("3. Eventos.");
        System.out.println("4. Ingressos.");
        System.out.println("5. Pagamentos.");
        System.out.println("6. Tipos de evento.");
        Scanner scanner = new Scanner(System.in);
        int opcao = scanner.nextInt();
        int escolha;
        String cpfPalestrante, cpfParticipante;
        int idEvento, idIngresso, idPagamento, idTipoEvento;
        
switch(opcao){
    case 1:
        System.out.println("Você escolheu a tabela Palestrantes.");
        System.out.println("Qual operação você deseja realizar?");
        System.out.println("1. Criar novo palestrante");
        System.out.println("2. Ver lista de palestrantes");
        System.out.println("3. Atualizar informações de um palestrante");
        System.out.println("4. Excluir um palestrante");
        escolha = scanner.nextInt();
        
        
        
        switch(escolha){
            case 1:
                Palestrantes.createPalestrantes();
                break;
            case 2:
                Palestrantes.readPalestrantes();
                break;
            case 3:
                System.out.println("Insira o cpf do palestrante: ");
                cpfPalestrante = scanner.nextLine();
                Palestrantes.updatePalestrante(cpfPalestrante);
                break;
            case 4:
                System.out.println("Insira o cpf do palestrante: ");
                cpfPalestrante = scanner.nextLine();
                Palestrantes.deletePalestrante(cpfPalestrante);
                break;
            default:
                System.out.println("Opção inválida. Por favor, selecione uma opção válida.");
                break;
        }
        break;
        
    case 2:
        System.out.println("Você escolheu a tabela Participantes.");
        System.out.println("Qual operação você deseja realizar?");
        System.out.println("1. Criar novo participante");
        System.out.println("2. Ver lista de participantes");
        System.out.println("3. Atualizar informações de um participante");
        System.out.println("4. Excluir um participante");
        escolha = scanner.nextInt();
        
        switch(escolha){
            case 1:
                Participantes.createParticipantes();
                break;
            case 2:
                Participantes.readParticipantes();
                break;
            case 3:
                System.out.println("Insira o cpf do participante: ");
                cpfParticipante = scanner.nextLine();
                Participantes.updateParticipante(cpfParticipante);
                break;
            case 4:
                System.out.println("Insira o cpf do participante: ");
                cpfParticipante = scanner.nextLine();
                Participantes.deleteParticipante(cpfParticipante);
                break;
            default:
                System.out.println("Opção inválida. Por favor, selecione uma opção válida.");
                break;
        }
        break;

    case 3:
        System.out.println("Você escolheu a tabela Eventos.");
        System.out.println("Qual operação você deseja realizar?");
        System.out.println("1. Criar novo evento");
        System.out.println("2. Ver lista de eventos");
        System.out.println("3. Atualizar informações de um evento");
        System.out.println("4. Excluir um evento");
        escolha = scanner.nextInt();
        
        switch(escolha){
            case 1:
                Eventos.createEvento();
                break;
            case 2:
                Eventos.readEventos();
                break;
            case 3:
                System.out.println("Insira o Id do evento:");
                idEvento = scanner.nextInt();
                Eventos.updateEvento(idEvento);
                break;
            case 4:
                System.out.println("Insira o Id do evento:");
                idEvento = scanner.nextInt();
                Eventos.deleteEvento(idEvento);
                break;
            default:
                System.out.println("Opção inválida. Por favor, selecione uma opção válida.");
                break;
        }
        break;

    case 4:
        System.out.println("Você escolheu a tabela Ingressos.");
        System.out.println("Qual operação você deseja realizar?");
        System.out.println("1. Criar novo ingresso");
        System.out.println("2. Ver lista de ingressos");
        System.out.println("3. Atualizar informações de um ingresso");
        System.out.println("4. Excluir um ingresso");
        escolha = scanner.nextInt();
        
        switch(escolha){
            case 1:
                Ingressos.createIngresso();
                break;
            case 2:
                Ingressos.readIngressos();
                break;
            case 3:
                System.out.println("Insira o Id do ingresso:");
                idIngresso = scanner.nextInt();
                Ingressos.updateIngresso(idIngresso);
                break;
            case 4:
                System.out.println("Insira o Id do ingresso:");
                idIngresso = scanner.nextInt();
                Ingressos.deleteIngresso(idIngresso);
                break;
            default:
                System.out.println("Opção inválida. Por favor, selecione uma opção válida.");
                break;
        }
        break;

    case 5:
        System.out.println("Você escolheu a tabela Pagamentos.");
        System.out.println("Qual operação você deseja realizar?");
        System.out.println("1. Criar novo pagamento");
        System.out.println("2. Ver lista de pagamentos");
        System.out.println("3. Atualizar informações de um pagamento");
        System.out.println("4. Excluir um pagamento");
        escolha = scanner.nextInt();
        
        switch(escolha){
            case 1:
                Pagamentos.createPagamento();
                break;
            case 2:
                Pagamentos.readPagamentos();
                break;
            case 3:
                System.out.println("Insira o Id do pagamento:");
                idPagamento = scanner.nextInt();
                Pagamentos.updatePagamento(idPagamento);
                break;
            case 4:
                System.out.println("Insira o Id do pagamento:");
                idPagamento = scanner.nextInt();
                Pagamentos.deletePagamento(idPagamento);
                break;
            default:
                System.out.println("Opção inválida. Por favor, selecione uma opção válida.");
                break;
        }
        break;

    case 6:
        System.out.println("Você escolheu a tabela Tipos de evento.");
        System.out.println("Qual operação você deseja realizar?");
        System.out.println("1. Criar novo tipo de evento");
        System.out.println("2. Ver lista de tipos de evento");
        System.out.println("3. Atualizar informações de um tipo de evento");
        System.out.println("4. Excluir um tipo de evento");
        escolha = scanner.nextInt();
        
        switch(escolha){
            case 1:
                TipoEvento.createTipoEvento();
                break;
            case 2:
                TipoEvento.readTipo();
                break;
            case 3:
                System.out.println("Insira o Id do tipo de evento:");
                idTipoEvento = scanner.nextInt();
                TipoEvento.updateTipoEvento(idTipoEvento);
                break;
            case 4:
                System.out.println("Insira o Id do tipo de evento:");
                idTipoEvento = scanner.nextInt();
                TipoEvento.deleteTipoEvento(idTipoEvento);
                break;
            default:
                System.out.println("Opção inválida. Por favor, selecione uma opção válida.");
                break;
        }
        break;

    default:
        System.out.println("Opção inválida. Por favor, selecione uma opção válida.");
        break;
}

        scanner.close();
    
    }
                     
}