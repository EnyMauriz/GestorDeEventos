package projetodb.main;

import java.util.Scanner;
import java.sql.*;

public class Pagamentos {
    private double totalCompra, numBoletoTransacao;
    
    public Pagamentos(double totalCompra, double numBoletoTransacao){
        this.totalCompra = totalCompra;
        this.numBoletoTransacao = numBoletoTransacao;
    }
    
    public static void createPagamento() {
    Scanner scanner = new Scanner(System.in);

    System.out.println("Insira o total da compra: ");
    double totalCompra = scanner.nextDouble();

    System.out.println("Insira o número do boleto/transação: ");
    double numBoletoTransacao = scanner.nextDouble();

    String sql = "INSERT INTO pagamento (total_compra, num_boleto_transacao) VALUES (?, ?)";

    try (Connection conexao = ConexaoBanco.obterConexao();
         PreparedStatement stmt = conexao.prepareStatement(sql)) {
        
        stmt.setDouble(1, totalCompra);
        stmt.setDouble(2, numBoletoTransacao);
        
        stmt.executeUpdate();
        System.out.println("Pagamento inserido com sucesso.");
        
    } catch (SQLException ex) {
        System.out.println("Erro ao inserir pagamento: " + ex.getMessage());
    }
}
    
    public static boolean verifyPagamento(int idPagamento) {
    String sql = "SELECT COUNT(*) FROM pagamento WHERE idpagamento = ?";

    try (Connection conexao = ConexaoBanco.obterConexao();
         PreparedStatement stmt = conexao.prepareStatement(sql)) {
    
        stmt.setInt(1, idPagamento);
        ResultSet rs = stmt.executeQuery();
    
        if (rs.next()) {
            int count = rs.getInt(1);  
            return count > 0; 
        }
    } catch (SQLException ex) {
        System.out.println("Erro: " + ex.getMessage());
    }

    return false;
}
    
    public static void updatePagamento(int idPagamento) {
    if (verifyPagamento(idPagamento)) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite as atualizações para o pagamento:");
        System.out.print("Novo total da compra: ");
        double totalCompra = scanner.nextDouble();

        System.out.print("Novo número do boleto/transação: ");
        double numBoletoTransacao = scanner.nextDouble();

        String sql = "UPDATE pagamento SET total_compra = ?, num_boleto_transacao = ? WHERE idpagamento = ?";

        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
             
            stmt.setDouble(1, totalCompra);
            stmt.setDouble(2, numBoletoTransacao);
            stmt.setInt(3, idPagamento);
            
            int linhasAfetadas = stmt.executeUpdate();
            
            if (linhasAfetadas > 0) {
                System.out.println(linhasAfetadas + " Pagamento atualizado com sucesso.");
            } else {
                System.out.println("Nenhum pagamento foi atualizado.");
            }
            
        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar pagamento: " + ex.getMessage());
        }
    } else {
        System.out.println("Pagamento não encontrado. Atualização não realizada.");
    }
}
    
    public static void deletePagamento(int idPagamento) {
    if (verifyPagamento(idPagamento)) {
        String sql = "DELETE FROM pagamento WHERE idpagamento = ?";

        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
             
            stmt.setInt(1, idPagamento);
            
            int linhasAfetadas = stmt.executeUpdate();
            
            if (linhasAfetadas > 0) {
                System.out.println(linhasAfetadas + " Pagamento deletado com sucesso.");
            } else {
                System.out.println("Nenhum pagamento foi deletado.");
            }
            
        } catch (SQLException ex) {
            System.out.println("Erro ao deletar pagamento: " + ex.getMessage());
        }
    } else {
        System.out.println("Pagamento não encontrado.");
    }
}
    
    public static void readPagamentos() {
    String sql = "SELECT * FROM pagamento";
    
    try (Connection conexao = ConexaoBanco.obterConexao();
         PreparedStatement stmt = conexao.prepareStatement(sql)) {
        
        ResultSet rs = stmt.executeQuery();
        if (!rs.isBeforeFirst()) {
            System.out.println("Nenhum pagamento encontrado.");
        }
        
        while (rs.next()) {
            int idPagamento = rs.getInt("idpagamento");
            double totalCompra = rs.getDouble("total_compra");
            double numBoletoTransacao = rs.getDouble("num_boleto_transacao");
            
            System.out.println("");
            System.out.println("Dados do pagamento: ");
            System.out.println("Id Pagamento: " + idPagamento);
            System.out.println("Total da compra: " + totalCompra);
            System.out.println("Número do boleto/transação: " + numBoletoTransacao);
        }
        
    } catch (SQLException ex) {
        System.out.println("Erro ao consultar pagamentos: " + ex.getMessage());
    }
}

    public double getTotalCompra() {
        return totalCompra;
    }

    public void setTotalCompra(double totalCompra) {
        this.totalCompra = totalCompra;
    }

    public double getNumBoletoTransacao() {
        return numBoletoTransacao;
    }

    public void setNumBoletoTransacao(double numBoletoTransacao) {
        this.numBoletoTransacao = numBoletoTransacao;
    }
    
    public void exibirInformacoes() {
        System.out.println("Informações do Pagamento:");
        System.out.println("Total da Compra: " + totalCompra);
        System.out.println("Número do Boleto/Transação: " + numBoletoTransacao);
    }
    
}
