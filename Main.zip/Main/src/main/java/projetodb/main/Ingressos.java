package projetodb.main;

import java.util.Scanner;
import java.sql.*;

public class Ingressos {
    private int idPagamento, idParticipante, statusIngresso;
    private double valor, desconto;
    
    public Ingressos(int idPagamento, int idParticipante, double desconto, double valor, int statusIngresso){

        this.idPagamento = idPagamento;
        this.idParticipante = idParticipante;
        this.desconto = desconto;
        this.valor = valor;
        this.statusIngresso = statusIngresso;
    }

    public static void createIngresso() {
    Scanner scanner = new Scanner(System.in);

    System.out.println("Insira o ID do pagamento: ");
    int idPagamento = scanner.nextInt();

    System.out.println("Insira o ID do participante: ");
    int idParticipante = scanner.nextInt();

    System.out.println("Insira o desconto: ");
    double desconto = scanner.nextDouble();

    System.out.println("Insira o valor do ingresso: ");
    double valor = scanner.nextDouble();

    System.out.println("Insira o status do ingresso (1 para ativo, 0 para inativo): ");
    int statusIngresso = scanner.nextInt();

    String sql = "INSERT INTO ingresso (idpagamento, idparticipante, desconto, valor, status_ingresso) VALUES (?, ?, ?, ?, ?)";

    try (Connection conexao = ConexaoBanco.obterConexao();
         PreparedStatement stmt = conexao.prepareStatement(sql)) {
        
        stmt.setInt(1, idPagamento);
        stmt.setInt(2, idParticipante);
        stmt.setDouble(3, desconto);
        stmt.setDouble(4, valor);
        stmt.setInt(5, statusIngresso);
        
        stmt.executeUpdate();
        System.out.println("Ingresso inserido com sucesso.");
        
    } catch (SQLException ex) {
        System.out.println("Erro ao inserir ingresso: " + ex.getMessage());
    }
}
    
    public static boolean verifyIngresso(int idIngresso) {
    String sql = "SELECT COUNT(*) FROM ingresso WHERE idingresso = ?";

    try (Connection conexao = ConexaoBanco.obterConexao();
         PreparedStatement stmt = conexao.prepareStatement(sql)) {
    
        stmt.setInt(1, idIngresso);
        ResultSet rs = stmt.executeQuery();
    
        if (rs.next()) {
            int count = rs.getInt(1);  
            return count > 0; 
        }
    } catch (SQLException ex) {
        System.out.println("Erro: " + ex.getMessage());
    }

    return false;
}
    
    public static void updateIngresso(int idIngresso) {
    if (verifyIngresso(idIngresso)) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Atualize os dados do ingresso:");
        System.out.print("Novo ID do pagamento: ");
        int idPagamento = scanner.nextInt();

        System.out.print("Novo ID do participante: ");
        int idParticipante = scanner.nextInt();

        System.out.print("Novo desconto: ");
        double desconto = scanner.nextDouble();

        System.out.print("Novo valor: ");
        double valor = scanner.nextDouble();

        System.out.print("Novo status do ingresso (1 para ativo, 0 para inativo): ");
        int statusIngresso = scanner.nextInt();

        String sql = "UPDATE ingresso SET idpagamento = ?, idparticipante = ?, desconto = ?, valor = ?, status_ingresso = ? WHERE idingresso = ?";

        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
             
            stmt.setInt(1, idPagamento);
            stmt.setInt(2, idParticipante);
            stmt.setDouble(3, desconto);
            stmt.setDouble(4, valor);
            stmt.setInt(5, statusIngresso);
            stmt.setInt(6, idIngresso);
            
            int linhasAfetadas = stmt.executeUpdate();
            
            if (linhasAfetadas > 0) {
                System.out.println(linhasAfetadas + " Ingresso atualizado com sucesso.");
            } else {
                System.out.println("Nenhum ingresso foi atualizado.");
            }
            
        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar ingresso: " + ex.getMessage());
        }
    } else {
        System.out.println("Ingresso não encontrado. Atualização não realizada.");
    }
}
    
    public static void deleteIngresso(int idIngresso) {
    if (verifyIngresso(idIngresso)) {
        String sql = "DELETE FROM ingresso WHERE idingresso = ?";

        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
             
            stmt.setInt(1, idIngresso);
            
            int linhasAfetadas = stmt.executeUpdate();
            
            if (linhasAfetadas > 0) {
                System.out.println(linhasAfetadas + " Ingresso deletado com sucesso.");
            } else {
                System.out.println("Nenhum ingresso foi deletado.");
            }
            
        } catch (SQLException ex) {
            System.out.println("Erro ao deletar ingresso: " + ex.getMessage());
        }
    } else {
        System.out.println("Ingresso não encontrado.");
    }
}
    
    public static void readIngressos() {
    String sql = "SELECT * FROM ingresso";
    
    try (Connection conexao = ConexaoBanco.obterConexao();
         PreparedStatement stmt = conexao.prepareStatement(sql)) {
        
        ResultSet rs = stmt.executeQuery();
        if (!rs.isBeforeFirst()) {
            System.out.println("Nenhum ingresso encontrado.");
        }
        
        while (rs.next()) {
            int idIngresso = rs.getInt("idingresso");
            int idPagamento = rs.getInt("idpagamento");
            int idParticipante = rs.getInt("idparticipante");
            double desconto = rs.getDouble("desconto");
            double valor = rs.getDouble("valor");
            int statusIngresso = rs.getInt("status_ingresso");
            
            System.out.println("");
            System.out.println("Dados do ingresso: ");
            System.out.println("ID Ingresso: " + idIngresso);
            System.out.println("ID Pagamento: " + idPagamento);
            System.out.println("ID Participante: " + idParticipante);
            System.out.println("Desconto: " + desconto);
            System.out.println("Valor: " + valor);
            System.out.println("Status: " + statusIngresso);
        }
        
    } catch (SQLException ex) {
        System.out.println("Erro ao consultar ingressos: " + ex.getMessage());
    }
}

    public int getIdPagamento() {
        return idPagamento;
    }

    public void setIdPagamento(int idPagamento) {
        this.idPagamento = idPagamento;
    }

    public int getIdParticipante() {
        return idParticipante;
    }

    public void setIdParticipante(int idParticipante) {
        this.idParticipante = idParticipante;
    }

    public int getStatusIngresso() {
        return statusIngresso;
    }

    public void setStatusIngresso(int statusIngresso) {
        this.statusIngresso = statusIngresso;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public double getDesconto() {
        return desconto;
    }

    public void setDesconto(double desconto) {
        this.desconto = desconto;
    }
    
    public void exibirInformacoes() {
        System.out.println("Informações do Ingresso:");
        System.out.println("ID do Pagamento: " + idPagamento);
        System.out.println("ID do Participante: " + idParticipante);
        System.out.println("Desconto: " + desconto);
        System.out.println("Valor: " + valor);
        System.out.println("Status do Ingresso: " + statusIngresso);
    }
}
